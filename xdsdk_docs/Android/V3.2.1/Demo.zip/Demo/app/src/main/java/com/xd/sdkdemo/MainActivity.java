package com.xd.sdkdemo;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.xd.xdsdk.ExitCallback;
import com.xd.xdsdk.XDCallback;
import com.xd.xdsdk.XDSDK;

import java.util.HashMap;
import java.util.Map;

@SuppressLint("NewApi")
public class MainActivity extends Activity {

    public static final String TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        final Button login, logout, accountswitch, payment, getUid, ucenter,
                hidewxlogin, hideqqlogin, hideguest, setqqweb, setwxweb, showvc,
                share;

        final TextView json = (TextView) findViewById(R.id.json);

        login = (Button) findViewById(R.id.login);
        logout = (Button) findViewById(R.id.logout);
        accountswitch = (Button) findViewById(R.id.exit);
        payment = (Button) findViewById(R.id.payment);
        getUid = (Button) findViewById(R.id.Uid);
        ucenter = (Button) findViewById(R.id.ucenter);

        hidewxlogin = (Button) findViewById(R.id.hide_wxlogin);
        hideqqlogin = (Button) findViewById(R.id.hide_qqlogin);
        hideguest = (Button) findViewById(R.id.hide_guestlogin);
        setqqweb = (Button) findViewById(R.id.qqweb);
        setwxweb = (Button) findViewById(R.id.wxweb);
        showvc = (Button) findViewById(R.id.show_vc);

        share = (Button)findViewById(R.id.wxshare);

        login.setEnabled(false);
        logout.setEnabled(false);
        getUid.setEnabled(false);
        ucenter.setEnabled(false);
        payment.setEnabled(false);
        share.setEnabled(false);


        XDSDK.setCallback(new XDCallback() {
            @Override
            public void onInitSucceed() {
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName());
                login.setEnabled(true);
                share.setEnabled(true);
            }

            @Override
            public void onInitFailed(String msg) {
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName() + ":" + msg);

            }

            @Override
            public void onLoginSucceed(String token) {
                logout.setEnabled(true);
                getUid.setEnabled(true);
                ucenter.setEnabled(true);
                payment.setEnabled(true);
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName() + ":" + token);
            }

            @Override
            public void onLoginFailed(String msg) {
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName() + ":" + msg);
            }

            @Override
            public void onLoginCanceled() {
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName() );
            }

            @Override
            public void onGuestBindSucceed(String token) {
                logout.setEnabled(true);
                getUid.setEnabled(true);
                ucenter.setEnabled(true);
                payment.setEnabled(true);
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName() + ":" + token);
            }

            @Override
            public void onLogoutSucceed() {
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName());
                logout.setEnabled(false);
                getUid.setEnabled(false);
                ucenter.setEnabled(false);
                payment.setEnabled(false);
            }

            @Override
            public void onPayCompleted() {
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName());
            }

            @Override
            public void onPayFailed(String msg) {
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName() + ":" + msg);
            }

            @Override
            public void onPayCanceled() {
                Log.e(TAG, Thread.currentThread().getStackTrace()[2].getMethodName());

            }
        });


//        XDSDK.initSDK(this, "c291rcxi568sckw", 1);
//        XDSDK.initSDK(this, "9hshhxi7c4wso8o", 0);
        XDSDK.initSDK(this, "a4d6xky5gt4c80s", 0);



        View.OnClickListener listener = new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                switch (v.getId()) {
                    case R.id.login:
                        XDSDK.login();
                        break;
                    case R.id.logout:
                        XDSDK.logout();
                        break;
                    case R.id.exit:
                        XDSDK.exit(new ExitCallback() {
                            @Override
                            public void onConfirm() {
                                super.onConfirm();
                            }

                            @Override
                            public void onCancle() {
                                super.onCancle();
                            }
                        });
                        break;
                    case R.id.payment:
                        Map<String, String> info = new HashMap<String, String>();
                        info.put("OrderId", "1234567890123456789012345678901234567890");
                        info.put("Product_Price", "1");
                        info.put("EXT", "abcd|efgh|1234|5678");
                        info.put("Sid", "2");
                        info.put("Role_Id", "3");
                        info.put("Product_Id", "4");
                        info.put("Product_Name", "648大礼包");
                        XDSDK.pay(info);
                        break;
                    case R.id.Uid:
                        json.setText("\nToken = " + XDSDK.getAccessToken());
                        Log.v("log", ",Token = " + XDSDK.getAccessToken());
                        break;
                    case R.id.ucenter:
                        XDSDK.openUserCenter();
                        break;
                    case R.id.hide_wxlogin:
                        XDSDK.hideWX();
                        break;
                    case R.id.hide_qqlogin:
                        XDSDK.hideQQ();
                        break;
                    case R.id.hide_guestlogin:
                        XDSDK.hideGuest();
                        break;
                    case R.id.qqweb:
                        XDSDK.setQQWeb();
                        break;
                    case R.id.wxweb:
                        XDSDK.setWXWeb();
                        break;
                    case R.id.show_vc:
                        XDSDK.showVC();
                        break;
                    case R.id.wxshare:
                        Intent intent = new Intent(MainActivity.this, WXShareActivity.class);
                        startActivity(intent);
                    default:
                        break;
                }
            }
        };

        login.setOnClickListener(listener);
        logout.setOnClickListener(listener);
        accountswitch.setOnClickListener(listener);
        payment.setOnClickListener(listener);
        getUid.setOnClickListener(listener);
        ucenter.setOnClickListener(listener);

        hidewxlogin.setOnClickListener(listener);
        hideqqlogin.setOnClickListener(listener);
        hideguest.setOnClickListener(listener);
        showvc.setOnClickListener(listener);
        setqqweb.setOnClickListener(listener);
        setwxweb.setOnClickListener(listener);
        share.setOnClickListener(listener);


        logout.setEnabled(false);
        getUid.setEnabled(false);
        ucenter.setEnabled(false);
        payment.setEnabled(false);



    }

}
