#Change Log

心动SDK_Unity 的 CHANGELOG 记录每次版本更新日志  面向开发

###Unity 1.0.7 - 2017-09-19（iOS-3.1.6&Android-3.1.5）
-更新 iOS SDK 修复游客登录回调流程问题

###Unity 1.0.6 - 2017-09-14（iOS-3.1.5&Android-3.1.5）
- 更新 iOS SDK 修复1.x版本SDK兼容问题

###Unity 1.0.5 - 2017-09-12（iOS-3.1.4&Android-3.1.5）

- 更新 iOS SDK
- 修复 iOS 游客账号可能丢失的问题

###Unity 1.0.4 - 2017-09-04（iOS-3.1.3&Android-3.1.5）

- 更新 Android SDK

###Unity 1.0.3 - 2017-08-30（iOS-3.1.3&Android-3.1.4）

- 更新 Android&iOS SDK
- 修复 Android&iOS 手机二次验证问题
- 修复 iOS用户注册问题

###Unity 1.0.2 - 2017-08-21（iOS-3.1.2&Android-3.1.3）

- 更新 Android SDK

###Unity 1.0.1 - 2017-08-15（iOS-3.1.2&Android-3.1.3）

- 新增微信分享接口
- 更新 iOS&Android SDK

###Unity 1.0.0 - 2017-08-07（iOS-3.1.1&Android-3.1.2）

- v1.0.0 SDK 发布
