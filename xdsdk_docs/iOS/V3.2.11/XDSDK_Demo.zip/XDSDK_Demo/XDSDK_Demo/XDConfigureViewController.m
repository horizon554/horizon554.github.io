//
//  XDConfigureViewController.m
//  XDSDK_Demo
//
//  Created by 杜凯强 on 2017/6/23.
//  Copyright © 2017年 XD. All rights reserved.
//

#import "XDConfigureViewController.h"

#import "XDSDKIntegrationViewController.h"

@interface XDConfigureViewController ()<UIScrollViewDelegate>{
    
    UIScrollView * _scroll;
    
    NSArray * _data;
}

@end

@implementation XDConfigureViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
     *工程配置
     *1 导入SDK
     *2 添加系统依赖库
     *3 配置 URL Types
     *4 配置 LSApplicationQueriesSchemes
     *5 配置 NSAppTransportSecurity
     *6 配置 AppDelegate OpenURL 函数
     */
    
    _data = @[@"导入SDK",@"添加系统依赖库",@"配置 URL Types",@"配置 LSApplicationQueriesSchemes",@"配置 NSAppTransportSecurity",@"配置 AppDelegate OpenURL 函数"];
    
    [self setTitle:@"工程配置"];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"下一步" style:UIBarButtonItemStylePlain target:self action:@selector(nextFunc)];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"上一步" style:UIBarButtonItemStylePlain target:self action:@selector(forwardFunc)];
    
    [self initUI];
}

- (BOOL)prefersStatusBarHidden{
    
    return NO;
}

- (void)forwardFunc{
    
    if (_scroll.contentOffset.x == 0) {
        
        [self.navigationController popViewControllerAnimated:YES];
    
    }else{
        
        [_scroll scrollRectToVisible:CGRectMake(_scroll.contentOffset.x - _scroll.frame.size.width, 0, _scroll.frame.size.width, _scroll.frame.size.height) animated:YES];
    }
}

- (void)nextFunc{
    
    if (_scroll.contentOffset.x == _scroll.frame.size.width * 5) {
        
        XDSDKIntegrationViewController * integrationVC = [[XDSDKIntegrationViewController alloc] init];
        
        [self.navigationController pushViewController:integrationVC animated:YES];
        
    }else{
        
        [_scroll scrollRectToVisible:CGRectMake(_scroll.contentOffset.x + _scroll.frame.size.width, 0, _scroll.frame.size.width, _scroll.frame.size.height) animated:YES];
    }
}

- (void)initUI{
    
    _scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.height, self.view.frame.size.width)];
    
    [_scroll setDelegate:self];
    
    [_scroll setContentSize:CGSizeMake(self.view.frame.size.height*6, self.view.frame.size.width-64)];
    
    [_scroll setPagingEnabled:YES];
    
    [_scroll setBounces:NO];
    
    [_scroll setScrollEnabled:NO];
    
    [self.view addSubview:_scroll];
    
    
    for (int i = 0; i < 6; i++) {
        
        UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(self.view.frame.size.height*i, 0, self.view.frame.size.height, self.view.frame.size.width)];
        
        [label setText:_data[i]];
        
        [label setBackgroundColor:[UIColor grayColor]];
        
        [_scroll addSubview:label];
    }
}


# pragma mark - UIScrollViewDelegate



@end
