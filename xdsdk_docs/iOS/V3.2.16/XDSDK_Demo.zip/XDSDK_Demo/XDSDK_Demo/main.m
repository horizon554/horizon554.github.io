//
//  main.m
//  XDSDK_Demo
//
//  Created by 杜凯强 on 2017/6/23.
//  Copyright © 2017年 XD. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
