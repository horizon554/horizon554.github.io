//
//  ViewController.m
//  XDSDK_Demo
//
//  Created by 杜凯强 on 2017/6/23.
//  Copyright © 2017年 XD. All rights reserved.
//

#import "ViewController.h"

#import "XDConfigureViewController.h"

#import "XDSDKViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    
    [super viewDidLoad];
    
    [self initUI];
    
}

- (BOOL)prefersStatusBarHidden{
    
    return NO;
}

- (void)initUI{
    
    UIButton * startBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    startBtn.frame = CGRectMake(0, 0, 200, 50);
    
    [startBtn.layer setBorderColor:[UIColor brownColor].CGColor];
    
    [startBtn.layer setBorderWidth:2.0f];
    
    [startBtn.layer setCornerRadius:5.0f];
    
    [startBtn setTitle:@"开始集成心动SDK" forState:UIControlStateNormal];
    
    [startBtn setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
    
    [startBtn setCenter:CGPointMake(self.view.center.x, self.view.center.y - 50)];
    
    [startBtn addTarget:self action:@selector(startFunc:) forControlEvents:UIControlEventTouchUpInside];
    
//    [self.view addSubview:startBtn];
    
    
    UIButton * skipBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    
    skipBtn.frame = CGRectMake(0, 0, 200, 50);
    
    [skipBtn.layer setBorderColor:[UIColor brownColor].CGColor];
    
    [skipBtn.layer setBorderWidth:2.0f];
    
    [skipBtn.layer setCornerRadius:5.0f];
    
    [skipBtn setTitle:@"心动SDK功能示例" forState:UIControlStateNormal];
    
    [skipBtn setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
    
    [skipBtn setCenter:CGPointMake(self.view.center.x, self.view.center.y)];
    
    [skipBtn addTarget:self action:@selector(skipFunc:) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:skipBtn];
}

- (void)startFunc:(UIButton*)sender{
    
    XDConfigureViewController * configureVC = [[XDConfigureViewController alloc] init];
    
    [self.navigationController pushViewController:configureVC animated:YES];
}


- (void)skipFunc:(UIButton*)sender{
    
    XDSDKViewController * xdsdkVC = [[XDSDKViewController alloc] init];
    
    [self.navigationController pushViewController:xdsdkVC animated:YES];
}

@end
