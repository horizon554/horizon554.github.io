//
//  AppDelegate.h
//  XDSDK_Demo
//
//  Created by 杜凯强 on 2017/6/23.
//  Copyright © 2017年 XD. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <FileProvider/FileProvider.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

