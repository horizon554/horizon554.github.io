//
//  XDSDKViewController.m
//  XDSDK_Demo
//
//  Created by 杜凯强 on 2017/6/23.
//  Copyright © 2017年 XD. All rights reserved.
//

#import "XDSDKViewController.h"

#import <XdComPlatform/XDCore.h>

#import "AppDelegate.h"

@interface XDSDKViewController ()<XDCallback>{
    
    UIButton * _initBtn;
    
    NSInteger _needInitTag;
    
    NSInteger _needLoginTag;
    
    NSInteger _otherTag;
}

@property(nonatomic,retain) UIButton *tryLogin;
@property(nonatomic,retain) UIButton *trylogout;
@property(nonatomic,retain) UIButton *tryaccountswitch;
@property(nonatomic,retain) UIButton *trypay;
@property(nonatomic,retain) UIButton *trygetUid;
@property(nonatomic,retain) UIButton *tryaccountStatus;
@property(nonatomic,retain) UIButton *openWebView;
@property(nonatomic,retain) UIButton *openGuester;
@property(nonatomic,retain) UIButton *openQQ;
@property(nonatomic,retain) UIButton *openWX;
@property(nonatomic,retain) UIButton *openXD;
@property(nonatomic,retain) UIButton *clearBtn;
@property(nonatomic,retain) UILabel *result;

@end

@implementation XDSDKViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    /*
     * 支付功能，App授权功能请自行配置
     * 竖屏请修改工程配置，SDK初始化参数，
     * Demo中横竖屏切换只作UI测试，请勿参考
     */
    
    _needInitTag = 999;
    
    _needLoginTag = 888;
    
    _otherTag = 666;
    
    [self setTitle:@"功能示例"];
    
    [self initResultView];
    
    [self initUI];
    
    [self setAutomaticallyAdjustsScrollViewInsets:NO];
}

- (BOOL)shouldAutorotate{
    
    return YES;
}

- (UIInterfaceOrientationMask)supportedInterfaceOrientations{
    
    if (self.lanScape) {
        
        [self resetResultFrame];
        
        return UIInterfaceOrientationMaskLandscapeLeft;
   
    }else{
        
        [self resetResultFrame];

        return UIInterfaceOrientationMaskPortrait;
    }
}

- (void)initSDK{
    
    [XDCore setCallBack:self];
    
    //0 横屏 1 竖屏
    if (self.lanScape) {
        
        [XDCore init:@"d4bjgwom9zk84wk" orientation:0];
        
    }else{
        
        [XDCore init:@"d4bjgwom9zk84wk" orientation:1];
    }

}

- (void)initUI{
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    _initBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [_initBtn setFrame:CGRectMake(20, 24, 80, 30)];
    [_initBtn setTitle:@"初始化" forState:UIControlStateNormal];
    [_initBtn addTarget:self action:@selector(initSDK) forControlEvents:UIControlEventTouchUpInside];
    [_initBtn setTag:_otherTag];
    [self.view addSubview:_initBtn];
    
    UIButton * orientationBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    [orientationBtn setFrame:CGRectMake(120, 24, 80, 30)];
    [orientationBtn addTarget:self action:@selector(screenAction:) forControlEvents:UIControlEventTouchUpInside];
    [orientationBtn setTitle:@"To竖屏" forState:UIControlStateSelected];
    [orientationBtn setTitle:@"To横屏" forState:UIControlStateNormal];
    orientationBtn.tag = _otherTag;
    [self.view addSubview:orientationBtn];
    
    self.tryLogin = [UIButton buttonWithType:UIButtonTypeSystem];
    self.tryLogin.frame = CGRectMake(20, 64, 80, 30);
    [self.tryLogin setTitle:@"登陆" forState:UIControlStateNormal];
    [self.tryLogin addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    self.tryLogin.tag = _needInitTag;
    [self.view addSubview:self.tryLogin];
    
    self.trylogout = [UIButton buttonWithType:UIButtonTypeSystem];
    self.trylogout.frame = CGRectMake(20,CGRectGetMaxY(self.tryLogin.frame) + 10, 80, 30);
    [self.trylogout setTitle:@"登出" forState:UIControlStateNormal];
    [self.trylogout addTarget:self action:@selector(logout) forControlEvents:UIControlEventTouchUpInside];
    self.trylogout.tag = _needLoginTag;
    [self.view addSubview:self.trylogout];
    
    self.tryaccountStatus = [UIButton buttonWithType:UIButtonTypeSystem];
    self.tryaccountStatus.frame = CGRectMake(20, CGRectGetMaxY(self.trylogout.frame) + 10, 80, 30);
    [self.tryaccountStatus setTitle:@"用户中心" forState:UIControlStateNormal];
    [self.tryaccountStatus addTarget:self action:@selector(openUserCenter) forControlEvents:UIControlEventTouchUpInside];
    self.tryaccountStatus.tag = _needLoginTag;
    [self.view addSubview:self.tryaccountStatus];
    
    self.trypay = [UIButton buttonWithType:UIButtonTypeSystem];
    self.trypay.frame = CGRectMake(20, CGRectGetMaxY(self.tryaccountStatus.frame) + 10, 80, 30);
    [self.trypay setTitle:@"支付" forState:UIControlStateNormal];
    [self.trypay addTarget:self action:@selector(pay) forControlEvents:UIControlEventTouchUpInside];
    self.trypay.tag = _needLoginTag;
    [self.view addSubview:self.trypay];
    
    
    self.trygetUid = [UIButton buttonWithType:UIButtonTypeSystem];
    self.trygetUid.frame = CGRectMake(120, 64, 80, 30);
    [self.trygetUid setTitle:@"获取账号ID" forState:UIControlStateNormal];
    [self.trygetUid addTarget:self action:@selector(getAccessToken) forControlEvents:UIControlEventTouchUpInside];
    self.trygetUid.tag = _needLoginTag;
    [self.view addSubview:self.trygetUid];
    
    UIButton * getVersion = [UIButton buttonWithType:UIButtonTypeSystem];
    [getVersion setFrame:CGRectMake(120, CGRectGetMaxY(self.trygetUid.frame) + 10, 80, 30)];
    [getVersion setTitle:@"获取版本号" forState:UIControlStateNormal];
    [getVersion addTarget:self action:@selector(getSDKVersion) forControlEvents:UIControlEventTouchUpInside];
    getVersion.tag= _otherTag;
    [self.view addSubview:getVersion];
    
    UIButton * hideGuestBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    [hideGuestBtn setFrame:CGRectMake(120, CGRectGetMaxY(getVersion.frame) + 10, 80, 30)];
    [hideGuestBtn setTitle:@"隐藏游客" forState:UIControlStateNormal];
    [hideGuestBtn addTarget:self action:@selector(hideGuestAction:) forControlEvents:UIControlEventTouchUpInside];
    hideGuestBtn.tag = _otherTag;
    [self.view addSubview:hideGuestBtn];
    
    UIButton * hideQQ = [UIButton buttonWithType:UIButtonTypeSystem];
    [hideQQ setFrame:CGRectMake(120, CGRectGetMaxY(hideGuestBtn.frame) + 10, 80, 30)];
    [hideQQ setTitle:@"隐藏QQ" forState:UIControlStateNormal];
    [hideQQ addTarget:self action:@selector(hideQQ) forControlEvents:UIControlEventTouchUpInside];
    hideQQ.tag = _otherTag;
    [self.view addSubview:hideQQ];
    
    UIButton * hideWX = [UIButton buttonWithType:UIButtonTypeSystem];
    [hideWX setFrame:CGRectMake(220, 64, 80, 30)];
    [hideWX setTitle:@"隐藏WX" forState:UIControlStateNormal];
    [hideWX addTarget:self action:@selector(hideWX) forControlEvents:UIControlEventTouchUpInside];
    hideWX.tag = _otherTag;
    [self.view addSubview:hideWX];
    
    UIButton * showVC = [UIButton buttonWithType:UIButtonTypeSystem];
    [showVC setFrame:CGRectMake(220, CGRectGetMaxY(hideWX.frame) + 10, 80, 30)];
    [showVC setTitle:@"显示VC" forState:UIControlStateNormal];
    [showVC addTarget:self action:@selector(showVC) forControlEvents:UIControlEventTouchUpInside];
    showVC.tag = _otherTag;
    [self.view addSubview:showVC];
    
    UIButton * wxWeb = [UIButton buttonWithType:UIButtonTypeSystem];
    [wxWeb setFrame:CGRectMake(220, CGRectGetMaxY(showVC.frame) + 10, 80, 30)];
    [wxWeb setTitle:@"WXWeb" forState:UIControlStateNormal];
    [wxWeb addTarget:self action:@selector(WXWeb) forControlEvents:UIControlEventTouchUpInside];
    wxWeb.tag = _otherTag;
    [self.view addSubview:wxWeb];
    
    UIButton * qqWeb = [UIButton buttonWithType:UIButtonTypeSystem];
    [qqWeb setFrame:CGRectMake(220, CGRectGetMaxY(wxWeb.frame) + 10, 80, 30)];
    [qqWeb setTitle:@"QQWeb" forState:UIControlStateNormal];
    [qqWeb addTarget:self action:@selector(QQWeb) forControlEvents:UIControlEventTouchUpInside];
    qqWeb.tag = _otherTag;
    [self.view addSubview:qqWeb];
    
    
    
    for (UIButton * sub in [self.view subviews]) {
        
        if ([sub isKindOfClass:[UIButton class]]) {
            
            [sub.layer setCornerRadius:5.0f];
            
            [sub.layer setBorderWidth:1.0f];
            
            [sub.layer setBorderColor:[UIColor brownColor].CGColor];
            
            [sub setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
        }
        
    }
    
    [self refereshBtn];
    
    [self.tryLogin.layer setBorderColor:[UIColor grayColor].CGColor];
    
    [self.tryLogin setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    
    [self.tryLogin setUserInteractionEnabled:NO];

}

- (void)refereshBtn{
    
    for (UIButton * sub in [self.view subviews]) {
        
        if ([sub isKindOfClass:[UIButton class]]) {
            
            [sub.layer setCornerRadius:5.0f];
            
            [sub.layer setBorderWidth:1.0f];
            
            [sub.layer setBorderColor:[UIColor brownColor].CGColor];
            
            [sub setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
            
            if (sub == self.tryLogin) {
                
                continue;
                
            }else if ([XDCore isLoggedIn] && sub.tag == _needLoginTag) {
                
                sub.userInteractionEnabled = YES;
                
            }else if (sub.tag == _otherTag){
                
                sub.userInteractionEnabled = YES;
                
            }else{
                
                sub.userInteractionEnabled = NO;
                
                [sub.layer setBorderColor:[UIColor grayColor].CGColor];
                
                [sub setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            }
        }
        
    }
    
}

- (void)hideGuestAction:(UIButton*)sender{
    
    [XDCore hideGuest];
}

- (void)hideWX{
    
    [XDCore hideWX];
}

- (void)hideQQ{
    
    [XDCore hideQQ];
}

- (void)showVC{
    
    [XDCore showVC];
}

- (void)QQWeb{
    
    [XDCore setQQWeb];
}

- (void)WXWeb{
    
    [XDCore setWXWeb];
}

- (void)login{
    
    [XDCore login];
}

- (void)logout{
    
    [XDCore logout];
}

- (void)pay
{
    NSMutableDictionary*mProductionInfo = [[NSMutableDictionary alloc]init];
    [mProductionInfo setObject:[self getOrderId] forKey:@"Order_Id"];
    [mProductionInfo setObject:@"1" forKey:@"Product_Price"];
    [mProductionInfo setObject:@"1" forKey:@"Product_Count"];
    [mProductionInfo setObject:@"1" forKey:@"EXT"];
    [mProductionInfo setObject:@"XDSDKPoint" forKey:@"Product_Id"];
    [mProductionInfo setObject:@"1" forKey:@"Role_Id"];
    [mProductionInfo setObject:@"1" forKey:@"Sid"];
    [mProductionInfo setObject:@"1亿金币" forKey:@"Product_Name"];
    [XDCore pay:mProductionInfo];
}

- (void)screenAction:(UIButton*)sender{
    
    sender.selected = !sender.selected;
    
    self.lanScape = sender.selected;
    
    if (self.lanScape) {
        
        [XDCore init:@"d4bjgwom9zk84wk" orientation:0];

    }else{
        
        [XDCore init:@"d4bjgwom9zk84wk" orientation:1];
    }
}

- (void)getAccessToken{
    
    [self simpleAlert:[XDCore getAccessToken]?[XDCore getAccessToken]:@"请确认SDK初始化和登录状态"];
}

- (void)getSDKVersion{
    
    [self simpleAlert:[XDCore getSDKVersion]];
}

- (void)openUserCenter{
    
    [XDCore openUserCenter];

}

- (BOOL)prefersStatusBarHidden{
    
    return NO;
}

-(void)simpleAlert:(NSString*)msg{
    
    UIAlertView * alert = [[UIAlertView alloc] initWithTitle:nil message:msg delegate:nil cancelButtonTitle:@"ok" otherButtonTitles:nil, nil];
    
    [alert show];
}

/**
 获取一个32位订单号
 
 @return 订单号
 */
- (NSString*)getOrderId{
    
    CFUUIDRef uuid_ref = CFUUIDCreate(NULL);
    
    CFStringRef uuid_string_ref= CFUUIDCreateString(NULL, uuid_ref);
    
    CFRelease(uuid_ref);
    
    NSString *uuid = [NSString stringWithString:(__bridge NSString*)uuid_string_ref];
    
    CFRelease(uuid_string_ref);
    
    return [uuid stringByReplacingOccurrencesOfString:@"-" withString:@""];
}

#pragma mark - XDCallback


/**
 初始化成功
 */
- (void)onInitSucceed{
    
    [self showResult:@"初始化成功" msg:nil];
    
    self.tryLogin.userInteractionEnabled = YES;
    
    [self.tryLogin.layer setBorderColor:[UIColor brownColor].CGColor];
    
    [self.tryLogin setTitleColor:[UIColor brownColor] forState:UIControlStateNormal];
    
    _initBtn.userInteractionEnabled = NO;
    
    [_initBtn.layer setBorderColor:[UIColor grayColor].CGColor];
    
    [_initBtn setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
}

/**
 初始化失败
 
 @param error_msg 错误信息
 */
- (void)onInitFailed:(nullable NSString*)error_msg{
    
    [self showResult:@"初始化失败" msg:error_msg];
    
    self.tryLogin.userInteractionEnabled = NO;
    
    [self.tryLogin.layer setBorderColor:[UIColor grayColor].CGColor];
    
    [self.tryLogin setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
}


/**
 登录成功
 
 @param access_token Token
 */
- (void)onLoginSucceed:(nonnull NSString*)access_token{
    
    [self showResult:@"登录成功" msg:access_token];
    
    [self refereshBtn];
}


/**
 登录失败
 
 @param error_msg 错误信息
 */
- (void)onLoginFailed:(nullable NSString*)error_msg{
    
    [self showResult:@"登录失败" msg:error_msg];
    
    [self refereshBtn];
}


/**
 登出成功
 */
- (void)onLogoutSucceed{
    
    [self showResult:@"登出成功" msg:nil];
    
    [self refereshBtn];
}


- (void)onLoginCanceled{
    
    [self showResult:@"登录取消" msg:nil];
    
    [self refereshBtn];
}

- (void)onGuestBindSucceed:(NSString *)token{
    
    [self showResult:@"游客升级成功" msg:token];
}

/**
 支付完成
 */
- (void)onPayCompleted{
    
    [self showResult:@"支付完成" msg:nil];
}


/**
 支付失败
 
 @param error_msg 错误信息
 */
- (void)onPayFailed:(nullable NSString*)error_msg{
    
    [self showResult:@"支付失败" msg:error_msg];
}


/**
 支付取消
 */
- (void)onPayCanceled{
    
    [self showResult:@"支付取消" msg:nil];
}

- (void)initResultView{
    
    _result = [[UILabel alloc] initWithFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 75, [UIScreen mainScreen].bounds.size.width, 75)];
    
    [_result setTextAlignment:NSTextAlignmentCenter];
    
    [_result setNumberOfLines:0];
    
    [_result setFont:[UIFont systemFontOfSize:22]];
    
    [_result setTextColor:[UIColor redColor]];
    
    [self.view addSubview:_result];
    
    _clearBtn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    
    [_clearBtn setFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - 80, CGRectGetMinY(_result.frame)-80, 75, 75)];
    
    [[_clearBtn titleLabel] setFont:[UIFont systemFontOfSize:22]];
    
    [_clearBtn setTitle:@"清除" forState:UIControlStateNormal];
    
    [_clearBtn setTag:_otherTag];
    
    [_clearBtn addTarget:self action:@selector(clearMsg) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:_clearBtn];
}

- (void)resetResultFrame{
    
    [_result setFrame:CGRectMake(0, [UIScreen mainScreen].bounds.size.height - 75, [UIScreen mainScreen].bounds.size.width, 75)];
    
    [_clearBtn setFrame:CGRectMake([UIScreen mainScreen].bounds.size.width - 80, CGRectGetMinY(_result.frame)-80, 75, 75)];
}

- (void)clearMsg{
    
    _result.text = nil;
}

- (void)showResult:(NSString*)title msg:(NSString*)msg{
    
    [UIView animateWithDuration:2.0 animations:^{
        
        if (msg) {
            
            [_result setText:[NSString stringWithFormat:@"%@:%@",title,msg]];
            
        }else{
            
            [_result setText:title];
        }
        
    } completion:^(BOOL finished) {
        
    }];
}




@end
