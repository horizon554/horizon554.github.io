//
//  XDSDKIntegrationViewController.m
//  XDSDK_Demo
//
//  Created by 杜凯强 on 2017/6/23.
//  Copyright © 2017年 XD. All rights reserved.
//

#import "XDSDKIntegrationViewController.h"

#import "XDSDKViewController.h"

@interface XDSDKIntegrationViewController (){
    
    UIScrollView * _scroll;
    
    NSArray * _data;
}

@end

@implementation XDSDKIntegrationViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /*
     *SDK集成
     *1 设置回调协议
     *2 实现回调协议
     *3 设置QQ、微信、游客、VeryCD是否显示
     *4 设置QQ、微信的授权方式
     *5 初始化心动SDK
     *6 用户登录
     */
    
    _data = @[@"设置回调协议",@"实现回调协议",@"设置QQ、微信、游客、VeryCD是否显示",@"设置QQ、微信的授权方式",@"初始化心动SDK",@"用户登录"];
    
    [self setTitle:@"SDK集成"];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"下一步" style:UIBarButtonItemStylePlain target:self action:@selector(nextFunc)];
    
    self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"上一步" style:UIBarButtonItemStylePlain target:self action:@selector(forwardFunc)];
    
    [self initUI];
}

- (BOOL)prefersStatusBarHidden{
    
    return NO;
}

- (void)forwardFunc{
    
    if (_scroll.contentOffset.x == 0) {
        
        [self.navigationController popViewControllerAnimated:YES];
        
    }else{
        
        [_scroll scrollRectToVisible:CGRectMake(_scroll.contentOffset.x - _scroll.frame.size.width, 0, _scroll.frame.size.width, _scroll.frame.size.height) animated:YES];
    }
}

- (void)nextFunc{
    
    if (_scroll.contentOffset.x == _scroll.frame.size.width * 5) {
        
        XDSDKViewController * xdsdkVC = [[XDSDKViewController alloc] init];
        
        [self.navigationController pushViewController:xdsdkVC animated:YES];
        
    }else{
        
        [_scroll scrollRectToVisible:CGRectMake(_scroll.contentOffset.x + _scroll.frame.size.width, 0, _scroll.frame.size.width, _scroll.frame.size.height) animated:YES];
    }
}

- (void)initUI{
    
    _scroll = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, self.view.frame.size.height, self.view.frame.size.width)];
        
    [_scroll setContentSize:CGSizeMake(self.view.frame.size.height*6, self.view.frame.size.width-64)];
    
    [_scroll setPagingEnabled:YES];
    
    [_scroll setScrollEnabled:NO];
    
    [_scroll setBounces:NO];
    
    [self.view addSubview:_scroll];
    
    
    for (int i = 0; i < 6; i++) {
        
        UILabel * label = [[UILabel alloc] initWithFrame:CGRectMake(self.view.frame.size.height*i, 0, self.view.frame.size.height, self.view.frame.size.width)];
        
        [label setText:_data[i]];
        
        [label setBackgroundColor:[UIColor grayColor]];
        
        [_scroll addSubview:label];
    }
}



@end
